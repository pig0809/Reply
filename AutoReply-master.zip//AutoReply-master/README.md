# AutoReply

# 這是一個LINE的聊天輔助系統
# 為單人帳號的小程式
# 主要功能為關鍵字設定與自動回覆
# 請至open.py輸入你的Token
# 請將程式中LINE("")的雙掛號內資料換成你的token
# 若第一次使用token可以留空
# 執行方法(僅簡介Android的方法)
# 請安裝以下app:
# 1.Termux
# 2.Quick Edit
# 3.Hackers keyboard